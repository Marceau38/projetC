#include <stdint.h>

struct structimg p3top1(struct structimg p3, char* nom_fichier);
