#include <stdint.h>

struct structimg p3top2(struct structimg p3, float a, float b, float c, char* nom_fichier);
