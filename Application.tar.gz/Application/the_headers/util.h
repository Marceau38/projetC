char *lignecommande(int argc, char *argv[], int* b, int* g, FILE **fichier);

struct structimg lectureFichier(FILE* fichier);
