#include <stdint.h>

struct structimg;
int write_file(struct structimg p, char* nom_fichier);
